import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
	def messageLog = messageLogFactory.getMessageLog(message);
	def debugInfo = """{
            "status": "second Attachment processed",
            "timestamp": "${new Date()}"
        }"""

	if (messageLog != null ) {
        
        def payloadName = 'Attachment';
	    
        messageLog.setStringProperty("Logging :", payloadName);
        
        String format = "text/plain";

        messageLog.addAttachmentAsString("Second Payload: ", debugInfo, format);

	}
	 return message

}
