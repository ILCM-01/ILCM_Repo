import com.sap.gateway.ip.core.customdev.util.Message
import java.net.URLDecoder
import java.nio.charset.StandardCharsets



def Message processData(Message message) {
    	def body       = message.getBody(java.lang.String) as String;
	def messageLog = messageLogFactory.getMessageLog(message);
	def debugInfo = """{
            "status": "processed",
            "timestamp": "${new Date()}"
        }"""

	if (messageLog != null ) {
        
        def payloadName = 'Attachment';
	    
        messageLog.setStringProperty("Logging :", payloadName);
        
        String format = "text/plain";

        messageLog.addAttachmentAsString("S4 Response Payload: ", debugInfo, format);

	}


    def headers = message.getHeaders()
    
    // Extract query parameters
    def encodedQuery = headers.get("CamelHttpQuery")  // e.g., "$filter=Status%20eq%20'Open'"

    if (encodedQuery) {
        // Decode the URL-encoded query parameters
        def decodedQuery = URLDecoder.decode(encodedQuery, StandardCharsets.UTF_8.name())
        
        // Store the decoded value as a property for later use
        message.setProperty("DecodedQuery", decodedQuery)
    }

    return message
}
